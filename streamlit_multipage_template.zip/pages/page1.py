import streamlit as st

def app():
    st.title("Home")
    nama = st.text_input("Masukkan nama kamu:")
    if nama:
        st.success(f"Halo, {nama}!")
