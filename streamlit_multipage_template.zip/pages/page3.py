import streamlit as st

def app():
    st.title("Settings")
    tema = st.selectbox("Pilih tema:", ["Default", "Light", "Dark"])
    st.write("Tema terpilih:", tema)
