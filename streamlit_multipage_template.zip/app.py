import streamlit as st

st.set_page_config(page_title="Aplikasi Latihan", page_icon="🏠")

st.sidebar.title("Navigasi")
page = st.sidebar.selectbox("Pilih Halaman:", ["Home", "Visualisasi Data", "Settings"])

if page == "Home":
    import pages.page1 as p1
    p1.app()
elif page == "Visualisasi Data":
    import pages.page2 as p2
    p2.app()
elif page == "Settings":
    import pages.page3 as p3
    p3.app()
